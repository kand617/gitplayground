TesterRequestLib
=================
This file was automatically generated for Stamplay by APIMATIC BETA v2.0 on 12/18/2015


How To Install: 
=============
The generated code relies on node package manager (npm) being available to resolve dependencies.
Once published you will need copy the folder 'testerrequestlib' in to your 'node_modules' folder.

  
How To Use:
===========
The following shows how import the controllers and use:

1) Import the module:

        var testerrequestlib = require('testerrequestlib');
2) Access various controllers by:

        var controller = testerrequestlib.XYZ;
        controller.getItems(id, callback);
    

